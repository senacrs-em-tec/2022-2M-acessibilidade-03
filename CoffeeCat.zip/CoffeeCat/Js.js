document.onkeydown = function(e) {
    if(e.keyCode === 30) { // The Enter/Return key
      document.activeElement.click();
    }
  };

  $('body').removeClass('paleta');
  $('body').addClass('protanopia');

